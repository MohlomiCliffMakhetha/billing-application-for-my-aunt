package cliffapplication;

import java.awt.Color;
import java.awt.Desktop;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JTextField;

public class Information {

    private double texFieldData;
    private double cost[];
    private double readings[] = new double[4];
    public Object dataToPass[];
    public boolean nextGUI = true;

    public Information() {
    }

    public Information(JTextField texFieldCost[], JTextField texFieldreadings[]) {

        cost = new double[texFieldCost.length];
        readings = new double[texFieldreadings.length];
        for (int i = 0; i < texFieldCost.length; i++) {
            if (numberFormatValidation(texFieldCost[i]) != -1) {
                cost[i] = numberFormatValidation(texFieldCost[i]);
            } else {
                nextGUI = false;
            }
        }
        for (int i = 0; i < texFieldreadings.length; i++) {
            if (numberFormatValidation(texFieldreadings[i]) != -1) {
                readings[i] = numberFormatValidation(texFieldreadings[i]);
            } else {
                nextGUI = false;
            }
        }
        if (nextGUI) {
            dataToPass = new Object[7];
            dataToPass[0] = cost;
            dataToPass[1] = readings;
            RecordClientBill clientRecord = new RecordClientBill(dataToPass);
            clientRecord.show();
        }
    }

    public double numberFormatValidation(JTextField texField) {
        try {
            texFieldData = Double.parseDouble(texField.getText());
            texField.setBackground(Color.green);
        } catch (NumberFormatException numberFormatException) {
            texField.setBackground(Color.red);
            texFieldData = -1;
        }
        return texFieldData;
    }

    public void invoice(Object data[]) throws IOException {
        double percent[] = {0, 0, 0, 0};
        double total;
        DateTimeFormatter date = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        LocalDateTime now = LocalDateTime.now();
        String folderName = "Tenets Electrical Bills";
        File folder = new File(System.getProperty("user.home"),folderName);
        boolean tenets = folder.mkdirs();
        for (int i = 0; i < ((String[]) data[2]).length; i++) {
            try {
                File file = new File(System.getProperty("user.home"),folderName+"//"+((String[]) data[2])[i] +" "+ date.format(now) + ".txt");
                FileWriter fileWriter = new FileWriter(file, true);
                BufferedWriter bufferwriter = new BufferedWriter(fileWriter);
                for (int j = 0; j < percent.length; j++) {
                    percent[j] = 0;
                }
                total = 0;
                for (int j = 0; j < ((double[]) data[3]).length; j++) {
                    percent[0] += ((double[]) data[3])[j];
                }
                percent[0] = ((double[]) data[3])[i] / percent[0];
                for (int j = 0; j < ((double[]) data[4]).length; j++) {
                    percent[1] += ((double[]) data[4])[j];
                }
                percent[1] = ((double[]) data[4])[i] / percent[1];
                for (int j = 0; j < ((double[]) data[5]).length; j++) {
                    percent[2] += ((double[]) data[5])[j];
                }
                percent[2] = ((double[]) data[5])[i] / percent[2];
                for (int j = 0; j < ((double[]) data[6]).length; j++) {
                    percent[3] += ((double[]) data[6])[j];
                }
                percent[3] = ((double[]) data[6])[i] / percent[3];
                bufferwriter.write("***********************Electricity Bill***********************");
                bufferwriter.write("\n\nCustomer                                  " + ((String[]) data[2])[i]);
                bufferwriter.write("\n\nENERGY READINGS (PEAK)                    " + String.format("%,-15.2fkW/h", ((double[]) data[1])[0] * percent[0]));
                bufferwriter.write("\nENERGY READINGS (STD)                     " + String.format("%,-15.2fkW/h", ((double[]) data[1])[1] * percent[1]));
                bufferwriter.write("\nENERGY READINGS (OFF)                     " + String.format("%,-15.2fkW/h", ((double[]) data[1])[2] * percent[2]));
                bufferwriter.write("\nREACTIVE ENERGY READINGS                  " + String.format("%,-15.2fkW/h", ((double[]) data[1])[3] * percent[3]));
                bufferwriter.write("\n---------------------------------------------------------------");
                bufferwriter.write("\n\nADMINISTRATION CHARGE                     R " + String.format("%,.2f", ((double[]) data[0])[0] / ((String[]) data[2]).length));
                total += (((double[]) data[0])[0] / ((String[]) data[2]).length);
                bufferwriter.write("\nDIST.NETWORK CAPACITY CHARGE              R " + String.format("%,.2f", ((double[]) data[0])[1] / ((String[]) data[2]).length));
                total += (((double[]) data[0])[1] / ((String[]) data[2]).length);
                bufferwriter.write("\nNETWORK DEMAND CHARGE                     R " + String.format("%,.2f", ((double[]) data[0])[2] / ((String[]) data[2]).length));
                total += (((double[]) data[0])[2] / ((String[]) data[2]).length);
                bufferwriter.write("\nANCILLARY SERVICE                         R " + String.format("%,.2f", ((double[]) data[0])[3] / ((String[]) data[2]).length));
                total += (((double[]) data[0])[3] / ((String[]) data[2]).length);
                bufferwriter.write("\nENERGY CHARGE (PEAK)                      R " + String.format("%,.2f", ((double[]) data[0])[4] * percent[0]));
                total += (((double[]) data[0])[4] * percent[0]);
                bufferwriter.write("\nENERGY CHARGE (STD)                       R " + String.format("%,.2f", ((double[]) data[0])[5] * percent[1]));
                total += (((double[]) data[0])[5] * percent[1]);
                bufferwriter.write("\nENERGY CHARGE (OFF)                       R " + String.format("%,.2f", ((double[]) data[0])[6] * percent[2]));
                total += (((double[]) data[0])[6] * percent[2]);
                bufferwriter.write("\nAFFORDABILITY SUBSIDY (ALL)               R " + String.format("%,.2f", ((double[]) data[0])[7] / ((String[]) data[2]).length));
                total += (((double[]) data[0])[7] / ((String[]) data[2]).length);
                bufferwriter.write("\nELECTRIFICATION AND RURAL SUBS (ALL)      R " + String.format("%,.2f", ((double[]) data[0])[8] / ((String[]) data[2]).length));
                total += (((double[]) data[0])[8] / ((String[]) data[2]).length);
                bufferwriter.write("\nREACTIVE ENERGY                           R " + String.format("%,.2f", ((double[]) data[0])[9] * percent[3]));
                total += (((double[]) data[0])[9] * percent[3]);
                bufferwriter.write("\nSERVICE CHARGE                            R " + String.format("%,.2f", ((double[]) data[0])[10] / ((String[]) data[2]).length));
                total += (((double[]) data[0])[10] / ((String[]) data[2]).length);
                bufferwriter.write("\n---------------------------------------------------------------");
                bufferwriter.write("\nTOTAL AMOUNT DUE                          R " + String.format("%,.2f", total));
                bufferwriter.close();
                Desktop.getDesktop().open(folder);
            } catch (IOException ex) {
                Logger.getLogger(Information.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

}
